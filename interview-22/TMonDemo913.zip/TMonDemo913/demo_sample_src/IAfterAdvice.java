package TMon;

//this is a interface for probe
public interface IAfterAdvice {
	void afterAdvice(int uids);
        void outCallProbe();
}
