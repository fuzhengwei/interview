Threading Monitor Agent v0.2

1.file list

bin\
startup.bat: start tomcat with TMon.dll agent, check the jdk path at the first line
shutdown.dat: shut down the tomcat, check the jdk path at the first line
TMon.dll:Threading Monitor Agent
TMon_bak.dll:speed-up version, rename file name to TMon.dll before using
(copy these files to tomcat\bin\)

demo_sample_src\
*.java files for 3 demos
(jdk1.5 needed, in jdk1.4, there are complie errors becauses of generic-type)

TMon_src\
TMon source files

TMondemo\
J2EE demos, copy this to tomcat\webapps\
business.jsp:user logon and run the business
show.jsp:show the result

2.Prepare

a.Tomcat5.0 version
b.SUN JDK1.5 version

3.Usage

a.copy files in bin\ to tomcat\bin
b.copy TMondemo to tomcat\webapps\
(if you use the tomcat I present, you just unzip the pack to a dir, then visit the addr:
http:\\localhost:18080\TMondemo\business.jsp to logon and run the business,
and visit http:\\localhost:18080\TMondemo\show.jsp to view the result)

Enjoy and thank you!
Li Ling, Aug.2006